import React, { useEffect, useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import {
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  Clock,
  Globe2,
  LockKeyhole,
  Mail,
  Phone as PhoneIcon,
  Search,
  Shield,
  Smartphone,
  Star
} from 'lucide-react';
import axios from 'axios';
import { toast } from 'sonner';
import mccMncList from 'mcc-mnc-list';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;
const carrierDataset = mccMncList.all();
const countryOptions = ['United States', 'Canada', 'United Kingdom'];
const normalizeServiceSearch = (value) => value.toLowerCase().replace(/[^a-z0-9]/g, '');
const countryAliases = {
  usa: 'United States',
  us: 'United States',
  'u.s.a': 'United States',
  'u.s.': 'United States',
  america: 'United States',
  canada: 'Canada',
  ca: 'Canada',
  uk: 'United Kingdom',
  gb: 'United Kingdom',
  britain: 'United Kingdom',
  england: 'United Kingdom'
};
const carrierCountryAliases = {
  'United States of America': 'United States',
  'United Kingdom of Great Britain and Northern Ireland': 'United Kingdom',
  'Republic of Korea': 'South Korea',
  'Russian Federation': 'Russia',
  'Viet Nam': 'Vietnam',
  'Iran (Islamic Republic of)': 'Iran',
  'Syrian Arab Republic': 'Syria',
  'Bolivia (Plurinational State of)': 'Bolivia',
  'Venezuela (Bolivarian Republic of)': 'Venezuela',
  'Moldova, Republic of': 'Moldova',
  'Tanzania, United Republic of': 'Tanzania',
  'Lao People’s Democratic Republic': 'Laos',
  'Brunei Darussalam': 'Brunei'
};

const normalizeCountryName = (value) => {
  const trimmed = value.trim();
  const alias = countryAliases[trimmed.toLowerCase()];
  if (alias) {
    return alias;
  }
  return countryOptions.find((country) => country.toLowerCase() === trimmed.toLowerCase()) || trimmed;
};

const getCarriersForCountry = (country) => {
  const normalizedCountry = normalizeCountryName(country);
  const carrierCountry = carrierCountryAliases[normalizedCountry] || normalizedCountry;
  return Array.from(
    new Set(
      carrierDataset
        .filter((item) => item.countryName === carrierCountry)
        .map((item) => item.brand || item.operator)
        .filter(Boolean)
    )
  ).sort((a, b) => a.localeCompare(b));
};

const LandingPage = () => {
  const [imei, setImei] = useState('');
  const [customerEmail, setCustomerEmail] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [country, setCountry] = useState('');
  const [carrierName, setCarrierName] = useState('');
  const [phoneModel, setPhoneModel] = useState('');
  const [checkImei, setCheckImei] = useState('');
  const [statusResult, setStatusResult] = useState(null);
  const [submissionResult, setSubmissionResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [services, setServices] = useState([]);
  const [selectedServiceType, setSelectedServiceType] = useState('icloud');
  const [selectedServiceId, setSelectedServiceId] = useState('');
  const [activeServiceIndex, setActiveServiceIndex] = useState(0);
  const [serviceSearchInput, setServiceSearchInput] = useState('');
  const [serviceSearchQuery, setServiceSearchQuery] = useState('');

  const serviceTypes = [
    { id: 'icloud', title: 'iCloud Service', copy: 'IMEI and email only', icon: LockKeyhole },
    { id: 'carrier', title: 'Carrier Unlock Service', copy: 'Country, carrier, model, IMEI and email', icon: Globe2 }
  ];

  const filteredServices = useMemo(() => {
    const query = serviceSearchQuery.trim().toLowerCase();
    const compactQuery = normalizeServiceSearch(serviceSearchQuery.trim());

    return services.filter((service) => {
      if ((service.service_type || 'icloud') !== selectedServiceType) {
        return false;
      }
      if (!query) {
        return true;
      }

      const searchableText = [
        service.name,
        service.description,
        service.badge,
        service.price === null || service.price === undefined ? '' : String(service.price)
      ].filter(Boolean).join(' ').toLowerCase();

      return searchableText.includes(query) || normalizeServiceSearch(searchableText).includes(compactQuery);
    });
  }, [services, selectedServiceType, serviceSearchQuery]);
  const carrierOptions = useMemo(() => getCarriersForCountry(country), [country]);

  useEffect(() => {
    fetchServices();
  }, []);

  useEffect(() => {
    if (filteredServices.length > 0 && !filteredServices.some((service) => service.id === selectedServiceId)) {
      setSelectedServiceId(filteredServices[0].id);
      setActiveServiceIndex(0);
    }
    if (filteredServices.length === 0) {
      setSelectedServiceId('');
      setActiveServiceIndex(0);
    }
  }, [services, selectedServiceType, selectedServiceId, filteredServices]);

  const fetchServices = async () => {
    try {
      const response = await axios.get(`${API}/services`);
      setServices(response.data);
    } catch (error) {
      toast.error('Failed to load services');
    }
  };

  const handleSliderMove = (direction) => {
    if (filteredServices.length === 0) {
      return;
    }
    const nextIndex = (activeServiceIndex + direction + filteredServices.length) % filteredServices.length;
    setActiveServiceIndex(nextIndex);
    setSelectedServiceId(filteredServices[nextIndex].id);
  };

  const handleServiceSearch = () => {
    setServiceSearchQuery(serviceSearchInput);
  };

  const handleSubmitImei = async (e) => {
    e.preventDefault();
    if (!selectedServiceId) {
      toast.error('Please select a service');
      return;
    }
    if (imei.length !== 15 || !/^\d+$/.test(imei)) {
      toast.error('IMEI must be exactly 15 digits');
      return;
    }

    setLoading(true);
    setSubmissionResult(null);
    try {
      const response = await axios.post(`${API}/imei`, {
        imei,
        customer_name: null,
        customer_email: customerEmail || null,
        customer_phone: selectedServiceType === 'carrier' ? customerPhone || null : null,
        country: selectedServiceType === 'carrier' ? normalizeCountryName(country) : null,
        carrier_name: selectedServiceType === 'carrier' ? carrierName : null,
        phone_model: selectedServiceType === 'carrier' ? phoneModel : null,
        service_type: selectedServiceType,
        service_id: selectedServiceId
      });
      setSubmissionResult(response.data);
      toast.success(response.data.payment_url ? 'Request created. Payment link is ready.' : 'Request submitted successfully.');
      setImei('');
      setCustomerEmail('');
      setCustomerPhone('');
      setCountry('');
      setCarrierName('');
      setPhoneModel('');
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Failed to submit request');
    } finally {
      setLoading(false);
    }
  };

  const handleCheckStatus = async (e) => {
    e.preventDefault();
    if (checkImei.length !== 15 || !/^\d+$/.test(checkImei)) {
      toast.error('IMEI must be exactly 15 digits');
      return;
    }
    setLoading(true);
    setStatusResult(null);
    try {
      const response = await axios.get(`${API}/imei/${checkImei}`);
      setStatusResult(response.data);
    } catch (error) {
      toast.error(error.response?.data?.detail || 'IMEI not found');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#f3f7fb] text-slate-900">
      <header className="bg-white border-b border-slate-200 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <a href="/" className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-md bg-[#087ec2] flex items-center justify-center">
              <Smartphone className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="text-lg font-bold text-[#087ec2]" style={{ fontFamily: 'Outfit, sans-serif' }}>UNLOCKMATE-LLC</div>
              <div className="text-xs text-slate-500 -mt-0.5">Fast, safe and online</div>
            </div>
          </a>
          <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600">
            <a href="#unlock" className="hover:text-[#087ec2]">Unlock</a>
            <a href="#status" className="hover:text-[#087ec2]">Order Status</a>
            <a href="#why" className="hover:text-[#087ec2]">Why Us</a>
            <a href="/admin" className="text-[#087ec2] hover:text-[#066aa3]" data-testid="admin-link">Admin</a>
          </nav>
        </div>
      </header>

      <main>
        <section id="unlock" className="relative overflow-hidden bg-white">
          <div className="absolute inset-y-0 right-0 w-full lg:w-1/2 bg-[#e8f5fc]"></div>
          <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14 lg:py-20">
            <div className="grid grid-cols-1 lg:grid-cols-[0.92fr_1.08fr] gap-10 lg:gap-14 items-start">
              <motion.div initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.55 }} className="pt-4">
                <div className="inline-flex items-center gap-2 bg-[#eaf7ef] text-[#24944d] border border-[#ccebd7] rounded-full px-4 py-2 text-xs font-bold uppercase tracking-wide mb-6">
                  <CheckCircle2 className="w-4 h-4" />
                  100% online IMEI unlock service
                </div>
                <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-slate-950 leading-[1.04]" style={{ fontFamily: 'Outfit, sans-serif' }}>
                  Unlock your Phone Permanently, quickly and professionally.
                </h1>
                <p className="mt-6 text-lg text-slate-600 leading-relaxed max-w-2xl">
                  Select your service, enter your device details, and pay through a secure NOWPayments checkout link.
                </p>
                <div className="mt-8 grid grid-cols-1 sm:grid-cols-3 gap-4">
                  {[
                    ['Fast', 'Simple online request'],
                    ['Safe', 'IMEI-based process'],
                    ['Support', 'Status tracking included']
                  ].map(([title, copy]) => (
                    <div key={title} className="bg-white border border-slate-200 rounded-lg p-4 shadow-sm">
                      <div className="text-sm font-bold text-slate-950">{title}</div>
                      <div className="text-xs text-slate-500 mt-1">{copy}</div>
                    </div>
                  ))}
                </div>
                <div className="mt-8 bg-amber-50 border border-amber-200 rounded-lg p-5">
                  <div className="flex gap-3">
                    <Clock className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
                    <div>
                      <h3 className="font-semibold text-amber-900">24-hour Refund Guarentee</h3>
                      <p className="text-sm text-amber-800 mt-1">Guaranteed unlock or full refund within 24 hours. Plus, get a complimentary phone information report.</p>
                    </div>
                  </div>
                </div>
              </motion.div>

              <motion.div initial={{ opacity: 0, y: 22 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.55, delay: 0.1 }} className="bg-white rounded-xl shadow-[0_18px_55px_rgba(15,23,42,0.16)] border border-slate-200 overflow-hidden">
                <div className="bg-[#087ec2] px-6 py-5 text-white">
                  <h2 className="text-2xl font-bold" style={{ fontFamily: 'Outfit, sans-serif' }}>Start your unlock request</h2>
                  <p className="text-sm text-blue-100 mt-1">Choose the exact service and enter your device information.</p>
                </div>

                <form onSubmit={handleSubmitImei} className="p-6 space-y-5">
                  <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-3">1. Choose service type</label>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3" data-testid="main-service-slider">
                      {serviceTypes.map((type) => {
                        const Icon = type.icon;
                        const selected = selectedServiceType === type.id;
                        return (
                          <button key={type.id} type="button" onClick={() => setSelectedServiceType(type.id)} className={`text-left rounded-lg border p-4 transition-all ${selected ? 'bg-[#e8f5fc] border-[#087ec2] ring-2 ring-[#087ec2]/15' : 'bg-white border-slate-200 hover:border-[#087ec2]/50'}`} data-testid={`main-service-${type.id}`}>
                            <Icon className={`w-5 h-5 mb-3 ${selected ? 'text-[#087ec2]' : 'text-slate-400'}`} />
                            <div className="font-bold text-slate-950">{type.title}</div>
                            <div className="text-xs text-slate-500 mt-1">{type.copy}</div>
                            {selected && <div className="mt-3 text-xs font-bold text-[#24944d]">Selected</div>}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  <div>
                    <div className="flex items-center justify-between gap-4 mb-3">
                      <label className="block text-sm font-semibold text-slate-700">2. Select package</label>
                      {filteredServices.length > 1 && (
                        <div className="flex items-center gap-2">
                          <button type="button" onClick={() => handleSliderMove(-1)} className="h-8 w-8 inline-flex items-center justify-center rounded-md border border-slate-200 text-slate-600 hover:bg-slate-50" aria-label="Previous service">
                            <ChevronLeft className="w-4 h-4" />
                          </button>
                          <button type="button" onClick={() => handleSliderMove(1)} className="h-8 w-8 inline-flex items-center justify-center rounded-md border border-slate-200 text-slate-600 hover:bg-slate-50" aria-label="Next service">
                            <ChevronRight className="w-4 h-4" />
                          </button>
                        </div>
                      )}
                    </div>
                    <div className="mb-3 flex gap-2">
                      <input
                        type="search"
                        value={serviceSearchInput}
                        onChange={(e) => {
                          setServiceSearchInput(e.target.value);
                          if (!e.target.value.trim()) {
                            setServiceSearchQuery('');
                          }
                        }}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') {
                            e.preventDefault();
                            handleServiceSearch();
                          }
                        }}
                        placeholder="Search service, e.g. AT&T"
                        className="min-w-0 flex-1 rounded-lg border border-slate-200 bg-white px-4 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-[#087ec2]/25 focus:border-[#087ec2]"
                        data-testid="service-search-input"
                      />
                      <button
                        type="button"
                        onClick={handleServiceSearch}
                        className="inline-flex h-[42px] items-center justify-center gap-2 rounded-lg bg-[#087ec2] px-4 text-sm font-bold text-white hover:bg-[#066aa3] focus:outline-none focus:ring-2 focus:ring-[#087ec2]/30"
                        data-testid="service-search-button"
                      >
                        <Search className="h-4 w-4" />
                        <span className="hidden sm:inline">Search</span>
                      </button>
                    </div>
                    {filteredServices.length > 0 ? (
                      <div className="flex gap-3 overflow-x-auto pb-2 snap-x" data-testid="service-slider">
                        {filteredServices.map((service, index) => {
                          const selected = selectedServiceId === service.id;
                          return (
                            <button key={service.id} type="button" onClick={() => { setSelectedServiceId(service.id); setActiveServiceIndex(index); }} className={`snap-start shrink-0 w-[245px] text-left rounded-lg border p-4 transition-all ${selected ? 'bg-[#eaf7ef] border-[#24944d] ring-2 ring-[#24944d]/15' : 'bg-white border-slate-200 hover:border-[#087ec2]/50'}`} data-testid={`service-slider-card-${service.name}`}>
                              <div className="flex items-start justify-between gap-2 mb-3">
                                <div className="text-sm font-bold text-slate-950 leading-snug">{service.name}</div>
                                {service.badge && <span className="shrink-0 bg-[#7ac943] text-white px-2 py-0.5 rounded text-[9px] font-bold uppercase tracking-wide">{service.badge}</span>}
                              </div>
                              <div className="text-2xl font-bold text-[#087ec2] mb-2">{service.price === null || service.price === undefined ? 'Price soon' : `$${service.price}`}</div>
                              <p className="text-xs text-slate-500 leading-relaxed">{service.description || 'Professional unlock service.'}</p>
                              {selected && <div className="mt-3 inline-flex items-center gap-1 text-xs font-bold text-[#24944d]"><CheckCircle2 className="w-3.5 h-3.5" /> Selected</div>}
                            </button>
                          );
                        })}
                      </div>
                    ) : (
                      <div className="rounded-lg border border-dashed border-slate-300 bg-slate-50 p-4 text-sm text-slate-500">
                        {serviceSearchQuery.trim()
                          ? `No ${selectedServiceType === 'carrier' ? 'carrier unlock' : 'iCloud'} services found for "${serviceSearchQuery.trim()}".`
                          : `No ${selectedServiceType === 'carrier' ? 'carrier unlock' : 'iCloud'} services added yet.`}
                      </div>
                    )}
                  </div>

                  {selectedServiceType === 'carrier' && (
                    <div className="space-y-4">
                      <SearchableInput
                        id="country"
                        label="Country *"
                        value={country}
                        onChange={(value) => {
                          setCountry(value);
                          setCarrierName('');
                        }}
                        onSelect={(value) => {
                          setCountry(value);
                          setCarrierName('');
                        }}
                        placeholder="Select USA, Canada, or UK"
                        options={countryOptions}
                        required
                        testId="country-input"
                      />

                      <div>
                        <SearchableInput
                          id="carrier-name"
                          label="Carrier *"
                          value={carrierName}
                          onChange={setCarrierName}
                          onSelect={setCarrierName}
                          placeholder={country ? 'Search or select carrier' : 'Select a country first'}
                          options={carrierOptions}
                          required
                          disabled={!country}
                          testId="carrier-name-input"
                        />
                        {country && (
                          <div className="mt-3 rounded-lg border border-slate-200 bg-slate-50 p-3">
                            <div className="flex items-center justify-between gap-3 mb-2">
                              <p className="text-xs font-bold uppercase tracking-wide text-slate-500">
                                Carriers for {normalizeCountryName(country)}
                              </p>
                              <span className="text-xs text-slate-500">{carrierOptions.length} found</span>
                            </div>
                            {carrierOptions.length > 0 ? (
                              <div className="max-h-32 overflow-y-auto flex flex-wrap gap-2 pr-1" data-testid="carrier-options-list">
                                {carrierOptions.map((carrier) => (
                                  <button
                                    key={carrier}
                                    type="button"
                                    onClick={() => setCarrierName(carrier)}
                                    className={`rounded-full border px-3 py-1.5 text-xs font-semibold transition-colors ${carrierName === carrier ? 'bg-[#087ec2] border-[#087ec2] text-white' : 'bg-white border-slate-200 text-slate-700 hover:border-[#087ec2]/60'}`}
                                  >
                                    {carrier}
                                  </button>
                                ))}
                              </div>
                            ) : (
                              <p className="text-sm text-slate-500">No carriers found in the database for this country. Type the carrier name manually.</p>
                            )}
                          </div>
                        )}
                      </div>

                      <TextInput id="phone-model" label="Phone Model *" value={phoneModel} onChange={setPhoneModel} placeholder="iPhone 15 Pro Max" required testId="phone-model-input" />
                    </div>
                  )}

                  <TextInput id="imei" label="IMEI Number *" value={imei} onChange={(value) => setImei(value.replace(/\D/g, ''))} placeholder="Enter 15-digit IMEI" required maxLength="15" mono testId="imei-input" />
                  <TextInput id="customer-email" type="email" label="Email *" value={customerEmail} onChange={setCustomerEmail} placeholder="your@email.com" required testId="customer-email-input" />
                  {selectedServiceType === 'carrier' && (
                    <TextInput id="customer-phone" type="tel" label="Contact Number (Optional)" value={customerPhone} onChange={setCustomerPhone} placeholder="Your phone" testId="customer-phone-input" />
                  )}

                  <button type="submit" disabled={loading} className="w-full bg-[#7ac943] text-white hover:bg-[#68b836] font-bold rounded-md px-6 py-3.5 transition-colors disabled:opacity-50 shadow-sm" data-testid="submit-imei-button">
                    {loading ? 'Creating secure payment...' : 'Continue to Secure Payment'}
                  </button>
                </form>

                {submissionResult && (
                  <div className="mx-6 mb-6 p-5 bg-[#eaf7ef] border border-[#ccebd7] rounded-lg" data-testid="payment-request-result">
                    <div className="flex items-start gap-3">
                      <CheckCircle2 className="w-5 h-5 text-[#24944d] shrink-0 mt-0.5" />
                      <div>
                        <h3 className="font-bold text-slate-950">Request created</h3>
                        <p className="text-sm text-slate-600 mt-1">
                          {submissionResult.service_name || 'Selected service'}
                          {submissionResult.service_price !== null && submissionResult.service_price !== undefined ? ` - $${submissionResult.service_price}` : ''}
                        </p>
                        {submissionResult.payment_url ? (
                          <a href={submissionResult.payment_url} target="_blank" rel="noreferrer" className="mt-4 inline-flex items-center justify-center bg-[#087ec2] text-white hover:bg-[#066aa3] font-bold rounded-md px-5 py-2.5 transition-colors" data-testid="pay-now-button">
                            Pay Now
                          </a>
                        ) : (
                          <p className="mt-3 text-sm text-amber-700">Payment request was not created because this service has no price yet.</p>
                        )}
                      </div>
                    </div>
                  </div>
                )}
              </motion.div>
            </div>
          </div>
        </section>

        <section className="bg-[#f3f7fb] border-y border-slate-200">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              [Smartphone, 'Choose your service', 'Select iCloud or carrier unlock and pick the right package.'],
              [Mail, 'Receive updates by email', 'Your request and payment details stay tied to your email and IMEI.'],
              [CheckCircle2, 'Track your request', 'Use your IMEI to check status and reopen payment when needed.']
            ].map(([Icon, title, copy]) => (
              <div key={title} className="flex gap-4 bg-white border border-slate-200 rounded-lg p-5 shadow-sm">
                <div className="h-11 w-11 rounded-md bg-[#e8f5fc] flex items-center justify-center shrink-0">
                  <Icon className="w-5 h-5 text-[#087ec2]" />
                </div>
                <div>
                  <h3 className="font-bold text-slate-950">{title}</h3>
                  <p className="text-sm text-slate-600 mt-1">{copy}</p>
                </div>
              </div>
            ))}
          </div>
        </section>

        <section id="status" className="py-16 bg-white">
          <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-8">
              <h2 className="text-3xl font-bold text-slate-950" style={{ fontFamily: 'Outfit, sans-serif' }}>Check Your Order Status</h2>
              <p className="text-slate-600 mt-2">Enter your IMEI to view your latest unlock status and payment link.</p>
            </div>
            <div className="bg-white border border-slate-200 rounded-xl shadow-sm p-6">
              <form onSubmit={handleCheckStatus} className="space-y-4">
                <TextInput id="check-imei" label="IMEI Number" value={checkImei} onChange={(value) => setCheckImei(value.replace(/\D/g, ''))} placeholder="Enter 15-digit IMEI" required maxLength="15" mono testId="check-imei-input" />
                <button type="submit" disabled={loading} className="w-full bg-[#087ec2] text-white hover:bg-[#066aa3] font-bold rounded-md px-6 py-3 transition-colors disabled:opacity-50" data-testid="check-status-button">
                  {loading ? 'Checking...' : 'Check Status'}
                </button>
              </form>

              {statusResult && (
                <div className="mt-6 p-5 bg-[#e8f5fc] border border-[#c8e6f7] rounded-lg" data-testid="status-result">
                  <div className="flex items-center gap-3 mb-4">
                    {statusResult.status === 'done' ? <CheckCircle2 className="w-6 h-6 text-[#24944d]" /> : <Clock className="w-6 h-6 text-amber-600" />}
                    <h3 className="text-lg font-bold text-slate-950">Status: {statusResult.status === 'done' ? 'Unlocked' : 'Pending'}</h3>
                  </div>
                  <div className="space-y-2 text-sm text-slate-700">
                    <p><strong>IMEI:</strong> <span style={{ fontFamily: 'JetBrains Mono, monospace' }}>{statusResult.imei}</span></p>
                    {statusResult.service_name && <p><strong>Service:</strong> {statusResult.service_name}</p>}
                    <p><strong>Submitted:</strong> {new Date(statusResult.submitted_at).toLocaleString()}</p>
                    <p><strong>Updated:</strong> {new Date(statusResult.updated_at).toLocaleString()}</p>
                  </div>
                  {statusResult.payment_url && (
                    <a href={statusResult.payment_url} target="_blank" rel="noreferrer" className="mt-4 inline-flex items-center justify-center bg-[#7ac943] text-white hover:bg-[#68b836] font-bold rounded-md px-5 py-2.5 transition-colors" data-testid="status-pay-now-button">
                      Open Payment Request
                    </a>
                  )}
                </div>
              )}
            </div>
          </div>
        </section>

        <section id="why" className="py-16 bg-[#f3f7fb]">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-10">
              <h2 className="text-3xl font-bold text-slate-950" style={{ fontFamily: 'Outfit, sans-serif' }}>Professional unlock service you can track</h2>
              <p className="text-slate-600 mt-2">A cleaner process with secure checkout and clear request details.</p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-5">
              {[
                [Shield, 'Secure', 'Payment requests are created through NOWPayments checkout.'],
                [LockKeyhole, 'Permanent', 'IMEI-based service flow for eligible devices.'],
                [Star, 'Transparent', 'Service prices are shown before submission,Full refund guarantee if your unlock is unsuccessful.'],
                [PhoneIcon, 'Support', 'Mail:unlockmateofficial@gmail.com']
              ].map(([Icon, title, copy]) => (
                <div key={title} className="bg-white border border-slate-200 rounded-lg p-6 shadow-sm">
                  <Icon className="w-7 h-7 text-[#087ec2] mb-4" />
                  <h3 className="font-bold text-slate-950">{title}</h3>
                  <p className="text-sm text-slate-600 mt-2">{copy}</p>
                </div>
              ))}
            </div>
          </div>
        </section>
      </main>

      <footer className="bg-[#1e2a36] text-white py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row justify-between gap-4 text-sm">
          <p>&copy; 2026 UNLOCKMATE. All rights reserved.</p>
          <div className="flex gap-5 text-slate-300">
            <a href="#status" className="hover:text-white">Order Status</a>
            <a href="/admin" className="hover:text-white">Admin Login</a>
          </div>
        </div>
      </footer>
    </div>
  );
};

const TextInput = ({ id, label, value, onChange, placeholder, type = 'text', required = false, maxLength, mono = false, testId }) => (
  <div>
    <label htmlFor={id} className="block text-sm font-semibold text-slate-700 mb-2">{label}</label>
    <input
      id={id}
      type={type}
      value={value}
      maxLength={maxLength}
      onChange={(e) => onChange(e.target.value)}
      placeholder={placeholder}
      required={required}
      className="w-full bg-white border border-slate-300 text-slate-950 rounded-md px-4 py-3 focus:outline-none focus:ring-2 focus:ring-[#087ec2]/25 focus:border-[#087ec2] placeholder:text-slate-400"
      style={mono ? { fontFamily: 'JetBrains Mono, monospace' } : undefined}
      data-testid={testId}
    />
  </div>
);

const SearchableInput = ({ id, label, value, onChange, onSelect, placeholder, options, required = false, disabled = false, testId }) => {
  const listId = `${id}-options`;
  const visibleOptions = useMemo(() => {
    const query = value.trim().toLowerCase();
    if (!query) {
      return options.slice(0, 80);
    }
    return options.filter((option) => option.toLowerCase().includes(query)).slice(0, 80);
  }, [options, value]);

  return (
    <div>
      <label htmlFor={id} className="block text-sm font-semibold text-slate-700 mb-2">{label}</label>
      <input
        id={id}
        type="text"
        value={value}
        list={listId}
        onChange={(e) => onChange(e.target.value)}
        onBlur={() => {
          const exactMatch = options.find((option) => option.toLowerCase() === value.trim().toLowerCase());
          if (exactMatch) {
            onSelect(exactMatch);
          }
        }}
        placeholder={placeholder}
        required={required}
        disabled={disabled}
        className="w-full bg-white border border-slate-300 text-slate-950 rounded-md px-4 py-3 focus:outline-none focus:ring-2 focus:ring-[#087ec2]/25 focus:border-[#087ec2] placeholder:text-slate-400 disabled:bg-slate-100 disabled:text-slate-400"
        data-testid={testId}
      />
      <datalist id={listId}>
        {visibleOptions.map((option) => (
          <option key={option} value={option} />
        ))}
      </datalist>
    </div>
  );
};

export default LandingPage;
