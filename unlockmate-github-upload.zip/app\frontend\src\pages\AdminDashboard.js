import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { LogOut, RefreshCw, CheckCircle2, Clock, Plus, Trash2 } from 'lucide-react';
import axios from 'axios';
import { toast } from 'sonner';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

const AdminDashboard = () => {
  const navigate = useNavigate();
  const [requests, setRequests] = useState([]);
  const [services, setServices] = useState([]);
  const [paymentConfigured, setPaymentConfigured] = useState(false);
  const [loading, setLoading] = useState(true);
  const [updatingId, setUpdatingId] = useState(null);
  const [serviceSaving, setServiceSaving] = useState(false);
  const [newService, setNewService] = useState({
    name: '',
    service_type: 'icloud',
    description: '',
    price: '',
    badge: '',
    sort_order: 0
  });
  const token = localStorage.getItem('admin_token');
  const username = localStorage.getItem('admin_username');

  useEffect(() => {
    if (!token) {
      navigate('/admin');
      return;
    }
    fetchRequests();
    fetchServices();
    fetchPaymentConfig();
  }, [token, navigate]);

  const fetchRequests = async () => {
    setLoading(true);
    try {
      const response = await axios.get(`${API}/admin/requests`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setRequests(response.data);
    } catch (error) {
      if (error.response?.status === 401) {
        toast.error('Session expired. Please login again.');
        handleLogout();
      } else {
        toast.error('Failed to fetch requests');
      }
    } finally {
      setLoading(false);
    }
  };

  const fetchServices = async () => {
    try {
      const response = await axios.get(`${API}/admin/services`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setServices(response.data);
    } catch (error) {
      toast.error('Failed to fetch services');
    }
  };

  const fetchPaymentConfig = async () => {
    try {
      const response = await axios.get(`${API}/admin/payment-config`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setPaymentConfigured(response.data.configured);
    } catch (error) {
      setPaymentConfigured(false);
    }
  };

  const handleCreateService = async (e) => {
    e.preventDefault();
    if (!newService.name.trim()) {
      toast.error('Service name is required');
      return;
    }
    setServiceSaving(true);
    try {
      await axios.post(
        `${API}/admin/services`,
        {
          name: newService.name.trim(),
          service_type: newService.service_type,
          description: newService.description.trim() || null,
          price: newService.price === '' ? null : Number(newService.price),
          badge: newService.badge.trim() || null,
          sort_order: Number(newService.sort_order) || 0,
          is_active: true
        },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      toast.success('Service added to slider');
      setNewService({ name: '', service_type: 'icloud', description: '', price: '', badge: '', sort_order: 0 });
      fetchServices();
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Failed to add service');
    } finally {
      setServiceSaving(false);
    }
  };

  const handleDeleteService = async (serviceId) => {
    try {
      await axios.delete(`${API}/admin/services/${serviceId}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      toast.success('Service removed from slider');
      fetchServices();
    } catch (error) {
      toast.error('Failed to remove service');
    }
  };

  const handleUpdateStatus = async (requestId, newStatus) => {
    setUpdatingId(requestId);
    try {
      await axios.patch(
        `${API}/admin/requests/${requestId}`,
        { status: newStatus },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      toast.success(`Status updated to ${newStatus}`);
      fetchRequests();
    } catch (error) {
      toast.error('Failed to update status');
    } finally {
      setUpdatingId(null);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('admin_token');
    localStorage.removeItem('admin_username');
    navigate('/admin');
  };

  return (
    <div className="min-h-screen bg-[#030712] text-white">
      <div className="bg-[#0B0F19] border-b border-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-medium tracking-tight text-white" style={{ fontFamily: 'Outfit, sans-serif' }}>Admin Dashboard</h1>
              <p className="text-sm text-gray-400 mt-1">Welcome, {username}</p>
            </div>
            <div className="flex items-center gap-3">
              <button onClick={fetchRequests} disabled={loading} className="flex items-center gap-2 bg-transparent border border-gray-700 text-white hover:bg-gray-800 rounded-md px-4 py-2 transition-colors disabled:opacity-50" data-testid="refresh-button">
                <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
                Refresh
              </button>
              <button onClick={handleLogout} className="flex items-center gap-2 bg-red-500/10 border border-red-500/20 text-red-400 hover:bg-red-500/20 rounded-md px-4 py-2 transition-colors" data-testid="logout-button">
                <LogOut className="w-4 h-4" />
                Logout
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }} className="bg-[#0B0F19]/70 backdrop-blur-xl border border-white/10 rounded-xl p-6">
            <div className="text-3xl font-bold text-sky-400 mb-2">{requests.length}</div>
            <div className="text-sm text-gray-400">Total Requests</div>
          </motion.div>
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, delay: 0.1 }} className="bg-[#0B0F19]/70 backdrop-blur-xl border border-white/10 rounded-xl p-6">
            <div className="text-3xl font-bold text-amber-400 mb-2">{requests.filter(r => r.status === 'pending').length}</div>
            <div className="text-sm text-gray-400">Pending</div>
          </motion.div>
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, delay: 0.2 }} className="bg-[#0B0F19]/70 backdrop-blur-xl border border-white/10 rounded-xl p-6">
            <div className="text-3xl font-bold text-green-400 mb-2">{requests.filter(r => r.status === 'done').length}</div>
            <div className="text-sm text-gray-400">Completed</div>
          </motion.div>
        </div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, delay: 0.25 }} className="bg-[#0B0F19]/70 backdrop-blur-xl border border-white/10 rounded-xl overflow-hidden mb-8">
          <div className="p-6 border-b border-gray-800 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
            <div>
              <h2 className="text-xl font-medium tracking-tight text-white" style={{ fontFamily: 'Outfit, sans-serif' }}>Slider Services</h2>
              <p className="text-sm text-gray-400 mt-1">Add or remove services shown on the homepage slider.</p>
            </div>
            <div className={`text-xs font-medium px-3 py-1 rounded-full border w-fit ${paymentConfigured ? 'text-green-400 border-green-400/20 bg-green-400/10' : 'text-amber-400 border-amber-400/20 bg-amber-400/10'}`}>
              NOWPayments {paymentConfigured ? 'configured' : 'not configured'}
            </div>
          </div>

          <div className="p-6 grid grid-cols-1 lg:grid-cols-[1fr_1.3fr] gap-6">
            <form onSubmit={handleCreateService} className="space-y-4">
              <div>
                <label htmlFor="service-name" className="block text-sm font-medium text-gray-300 mb-2">Service Name</label>
                <input id="service-name" type="text" value={newService.name} onChange={(e) => setNewService({ ...newService, name: e.target.value })} placeholder="iPhone 15 Series Unlock" className="w-full bg-gray-900/50 border border-gray-800 text-white rounded-md px-4 py-3 focus:outline-none focus:ring-2 focus:ring-sky-500/50 focus:border-sky-500 placeholder:text-gray-600" data-testid="service-name-input" />
              </div>
              <div>
                <label htmlFor="service-type" className="block text-sm font-medium text-gray-300 mb-2">Main Service Type</label>
                <select id="service-type" value={newService.service_type} onChange={(e) => setNewService({ ...newService, service_type: e.target.value })} className="w-full bg-gray-900/50 border border-gray-800 text-white rounded-md px-4 py-3 focus:outline-none focus:ring-2 focus:ring-sky-500/50 focus:border-sky-500" data-testid="service-type-input">
                  <option value="icloud">iCloud Service</option>
                  <option value="carrier">Carrier Unlock Service</option>
                </select>
              </div>
              <div>
                <label htmlFor="service-description" className="block text-sm font-medium text-gray-300 mb-2">Description</label>
                <textarea id="service-description" value={newService.description} onChange={(e) => setNewService({ ...newService, description: e.target.value })} placeholder="Short text shown on the slider" rows="3" className="w-full bg-gray-900/50 border border-gray-800 text-white rounded-md px-4 py-3 focus:outline-none focus:ring-2 focus:ring-sky-500/50 focus:border-sky-500 placeholder:text-gray-600 resize-none" data-testid="service-description-input" />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label htmlFor="service-price" className="block text-sm font-medium text-gray-300 mb-2">Price USD</label>
                  <input id="service-price" type="number" min="0" step="0.01" value={newService.price} onChange={(e) => setNewService({ ...newService, price: e.target.value })} placeholder="69" className="w-full bg-gray-900/50 border border-gray-800 text-white rounded-md px-4 py-3 focus:outline-none focus:ring-2 focus:ring-sky-500/50 focus:border-sky-500 placeholder:text-gray-600" data-testid="service-price-input" />
                </div>
                <div>
                  <label htmlFor="service-badge" className="block text-sm font-medium text-gray-300 mb-2">Badge</label>
                  <input id="service-badge" type="text" value={newService.badge} onChange={(e) => setNewService({ ...newService, badge: e.target.value })} placeholder="Popular" className="w-full bg-gray-900/50 border border-gray-800 text-white rounded-md px-4 py-3 focus:outline-none focus:ring-2 focus:ring-sky-500/50 focus:border-sky-500 placeholder:text-gray-600" data-testid="service-badge-input" />
                </div>
                <div>
                  <label htmlFor="service-order" className="block text-sm font-medium text-gray-300 mb-2">Order</label>
                  <input id="service-order" type="number" value={newService.sort_order} onChange={(e) => setNewService({ ...newService, sort_order: e.target.value })} className="w-full bg-gray-900/50 border border-gray-800 text-white rounded-md px-4 py-3 focus:outline-none focus:ring-2 focus:ring-sky-500/50 focus:border-sky-500 placeholder:text-gray-600" data-testid="service-order-input" />
                </div>
              </div>
              <button type="submit" disabled={serviceSaving} className="inline-flex items-center justify-center gap-2 bg-sky-400 text-gray-950 hover:bg-sky-500 font-medium rounded-md px-5 py-3 transition-colors disabled:opacity-50" data-testid="add-service-button">
                <Plus className="w-4 h-4" />
                {serviceSaving ? 'Adding...' : 'Add Service'}
              </button>
            </form>

            <div className="space-y-3">
              {services.length === 0 ? (
                <div className="h-full min-h-[220px] flex items-center justify-center border border-dashed border-gray-800 rounded-lg text-gray-500">
                  No slider services yet
                </div>
              ) : (
                services.map((service) => (
                  <div key={service.id} className="flex items-start justify-between gap-4 bg-gray-900/40 border border-gray-800 rounded-lg p-4">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="font-semibold text-white">{service.name}</h3>
                        <span className="bg-gray-800 text-gray-300 border border-gray-700 rounded-full px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider">{(service.service_type || 'icloud') === 'carrier' ? 'Carrier' : 'iCloud'}</span>
                        {service.badge && <span className="bg-sky-400/10 text-sky-400 border border-sky-400/20 rounded-full px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider">{service.badge}</span>}
                      </div>
                      <div className="text-sm text-sky-400 font-semibold mb-1">{service.price === null || service.price === undefined ? 'Price not set' : `$${service.price}`}</div>
                      <p className="text-sm text-gray-400">{service.description || 'No description'}</p>
                    </div>
                    <button onClick={() => handleDeleteService(service.id)} className="h-9 w-9 shrink-0 inline-flex items-center justify-center rounded-md border border-red-500/20 text-red-400 hover:bg-red-500/10 transition-colors" aria-label={`Remove ${service.name}`} data-testid={`delete-service-${service.name}`}>
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, delay: 0.3 }} className="bg-[#0B0F19]/70 backdrop-blur-xl border border-white/10 rounded-xl overflow-hidden">
          <div className="p-6 border-b border-gray-800">
            <h2 className="text-xl font-medium tracking-tight text-white" style={{ fontFamily: 'Outfit, sans-serif' }}>IMEI Requests</h2>
          </div>

          {loading ? (
            <div className="p-12 text-center text-gray-500">Loading requests...</div>
          ) : requests.length === 0 ? (
            <div className="p-12 text-center text-gray-500">No requests yet</div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full" data-testid="requests-table">
                <thead className="bg-gray-900/50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">IMEI</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Customer</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Contact</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Service</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Status</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Submitted</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-800">
                  {requests.map((request) => (
                    <tr key={request.id} className="hover:bg-gray-900/30 transition-colors">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className="font-mono text-sm text-sky-400">{request.imei}</span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-300">{request.customer_name || '-'}</td>
                      <td className="px-6 py-4 text-sm text-gray-300">
                        <div className="space-y-1">
                          {request.customer_email && <div className="text-xs">{request.customer_email}</div>}
                          {request.customer_phone && <div className="text-xs">{request.customer_phone}</div>}
                          {!request.customer_email && !request.customer_phone && '-'}
                        </div>
                      </td>
                      <td className="px-6 py-4 text-sm text-gray-300">
                        <div>{request.service_name || '-'}</div>
                        <div className="text-xs text-gray-500">{(request.service_type || 'icloud') === 'carrier' ? 'Carrier Unlock' : 'iCloud Service'}</div>
                        {request.service_price !== null && request.service_price !== undefined && <div className="text-xs text-sky-400">${request.service_price}</div>}
                        {(request.country || request.carrier_name || request.phone_model) && (
                          <div className="mt-1 text-xs text-gray-400">
                            {[request.country, request.carrier_name, request.phone_model].filter(Boolean).join(' / ')}
                          </div>
                        )}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-medium ${request.status === 'done' ? 'bg-green-400/10 text-green-400 border border-green-400/20' : 'bg-amber-400/10 text-amber-400 border border-amber-400/20'}`}>
                          {request.status === 'done' ? <CheckCircle2 className="w-3 h-3" /> : <Clock className="w-3 h-3" />}
                          {request.status}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-400">{new Date(request.submitted_at).toLocaleDateString()}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm">
                        <div className="flex items-center gap-2">
                          {request.status === 'pending' ? (
                            <button onClick={() => handleUpdateStatus(request.id, 'done')} disabled={updatingId === request.id} className="bg-green-500/10 border border-green-500/20 text-green-400 hover:bg-green-500/20 rounded px-3 py-1 transition-colors disabled:opacity-50 text-xs font-medium" data-testid={`mark-done-button-${request.imei}`}>
                              {updatingId === request.id ? 'Updating...' : 'Mark Done'}
                            </button>
                          ) : (
                            <button onClick={() => handleUpdateStatus(request.id, 'pending')} disabled={updatingId === request.id} className="bg-amber-500/10 border border-amber-500/20 text-amber-400 hover:bg-amber-500/20 rounded px-3 py-1 transition-colors disabled:opacity-50 text-xs font-medium" data-testid={`mark-pending-button-${request.imei}`}>
                              {updatingId === request.id ? 'Updating...' : 'Mark Pending'}
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </motion.div>
      </div>
    </div>
  );
};

export default AdminDashboard;
