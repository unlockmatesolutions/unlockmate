# Test Credentials

## Admin Account
- **Username:** admin
- **Password:** mohitsha11

## Test IMEI Numbers
You can use any 15-digit number for testing, for example:
- 123456789012345
- 987654321098765
